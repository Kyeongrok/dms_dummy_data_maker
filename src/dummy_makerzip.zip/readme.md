# aux_info생성

## id생성하기
dw_<vin>_yymmdd_hhmmss 형식으로 만든다
