import os, sys

path = os.getcwd()
print ("The current working directory is %s" % path)

#path = "~/ifs/"
# /ifs/mfc/data/mobis/L4_FR_CMR/10_raw/dw_1438_20190513

path = "/Users/kyeongrok/ifs/hello"
os.mkdir(path, 755)

